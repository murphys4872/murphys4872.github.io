# Shemar Murphy
# October 12, 2025
# P2HW2_MurphyShemar
# This program asks the user to enter grades for six modules,
# stores them in a list, and displays the lowest grade, highest grade,
# sum, and average of the grades, all neatly formatted.

"""
Pseudocode:
1. Display program purpose
2. Ask user to enter six grades (one for each module)
3. Store all six grades in a list named 'module_grades'
4. Calculate:
    a. The lowest grade using min()
    b. The highest grade using max()
    c. The sum of all grades using sum()
    d. The average using sum() / len()
5. Display all results formatted with labels and aligned spacing
   - Show average with two decimal places
"""

# Step 1: Ask user for six module grades
mod1 = float(input("Enter grade for Module 1: "))
mod2 = float(input("Enter grade for Module 2: "))
mod3 = float(input("Enter grade for Module 3: "))
mod4 = float(input("Enter grade for Module 4: "))
mod5 = float(input("Enter grade for Module 5: "))
mod6 = float(input("Enter grade for Module 6: "))

# Step 2: Store grades in a list
module_grades = [mod1, mod2, mod3, mod4, mod5, mod6]

# Step 3: Perform calculations
lowest = min(module_grades)
highest = max(module_grades)
total = sum(module_grades)
average = total / len(module_grades)

# Step 4: Display formatted results
print("\n------------Results------------")
print(f"{'Lowest Grade:':20}{lowest}")
print(f"{'Highest Grade:':20}{highest}")
print(f"{'Sum of Grades:':20}{total}")
print(f"{'Average:':20}{average:.2f}")
print("--------------------------------")
