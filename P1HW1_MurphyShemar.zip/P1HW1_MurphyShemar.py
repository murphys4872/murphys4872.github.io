# -----Calculating Exponenets----

print("-----Calculating Exponenets----\n")

# Get input for base and exponent
base = int(input("Enter an integer as the base value: "))
exponent = int(input("Enter an integer as the exponent: "))

# Perform exponentiation
result = base ** exponent
print(f"\n{base} raised to the power of {exponent} is {result} !!\n")

# -----Addition and Subtraction----
print("-----Addition and Subtraction----\n")

# Get input for addition and subtraction
start = int(input("Enter a starting integer: "))
add = int(input("Enter an integer to add: "))
subtract = int(input("Enter an integer to subtract: "))

# Perform the operations
final_result = start + add - subtract
print(f"\n{start} + {add} - {subtract} is equal to {final_result}")
