# Shemar Murphy
# October 4th, 2025
# Assignment: P1LAB1 
# Description: This program reads input and prints output.

first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

# Display a welcome message that matches the example
print("Hello,", first_name, last_name + "! Welcome to CTI-110")
