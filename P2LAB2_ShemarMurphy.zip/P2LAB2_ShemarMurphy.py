# Shemar Murphy
# October 12, 2025
# P2LAB2
# This program creates a dictionary of vehicles and their MPG values. 
# It asks the user to select a vehicle, displays its MPG, then calculates 
# how many gallons of gas are needed to drive a given number of miles.

# Create dictionary of vehicles and MPG values
vehicle_mpg = {
    "Camaro": 18.21,
    "Prius": 52.36,
    "Model S": 110,
    "Silverado": 26
}

# Create variable that holds all keys
keys = vehicle_mpg.keys()

# Display available vehicles
print(keys)

# Prompt user to choose a vehicle
vehicle_choice = input("\nEnter a vehicle to see it's mpg: ")

# Display MPG and calculate fuel usage
if vehicle_choice in vehicle_mpg:
    mpg = vehicle_mpg[vehicle_choice]
    print(f"\nThe {vehicle_choice} gets {mpg} mpg.")
    
    # Ask how many miles will be driven
    miles = float(input(f"\nHow many miles will you drive the {vehicle_choice}? "))
    
    # Calculate gallons needed
    gallons_needed = miles / mpg
    
    # Display result
    print(f"\n{gallons_needed:.2f} gallon(s) of gas are needed to drive the {vehicle_choice} {miles:.1f} miles.")
else:
    print("\nThat vehicle is not in the list. Please check your spelling and try again.")
