"""
#P3LAB_LastnameFirstname.py
#Shemar Murphy
#This program reads a money amount and calculates the most efficient
number of dollars, quarters, dimes, nickels, and pennies to make that amount.
"""

# Read input from user
money = float(input("Enter an amount of money (e.g., 12.34): "))

# Convert dollars to cents to avoid floating point issues
cents = int(round(money * 100))

# Calculate dollars
dollars = cents // 100
cents = cents - dollars * 100

# Calculate quarters
quarters = cents // 25
cents = cents - quarters * 25

# Calculate dimes
dimes = cents // 10
cents = cents - dimes * 10

# Calculate nickels
nickels = cents // 5
cents = cents - nickels * 5

# Remaining cents are pennies
pennies = cents

# Output the results
print(f"Dollars: {dollars}")
print(f"Quarters: {quarters}")
print(f"Dimes: {dimes}")
print(f"Nickels: {nickels}")
print(f"Pennies: {pennies}")
