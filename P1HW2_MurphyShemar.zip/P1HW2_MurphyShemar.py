# Shemar Murphy
# 2025-10-05
# P1HW2_MurphyShemar.py
# This program asks the user for their travel budget and expenses,
# calculates the total spent, and displays the remaining balance.

# Pseudocode (Program Logic):
# 1. Display a welcome message (optional)
# 2. Ask user to enter budget → store in variable "budget"
# 3. Ask user to enter travel destination → store in variable "destination"
# 4. Ask user to enter amount for gas → store in variable "gas"
# 5. Ask user to enter amount for accommodation → store in variable "accommodation"
# 6. Ask user to enter amount for food → store in variable "food"
# 7. Add expenses: gas + accommodation + food → store in variable "expenses"
# 8. Subtract expenses from budget → store result in "remaining"
# 9. Display travel destination, budget, each expense, total expenses, and remaining balance

# Step 3: Ask user for budget
budget = float(input("Enter your budget: "))

# Step 4: Ask user for travel destination
destination = input("Enter your travel destination: ")

# Step 5: Ask for gas expenses
gas = float(input("How much will you spend on gas? "))

# Step 6: Ask for accommodation expenses
accommodation = float(input("How much will you spend on accommodation? "))

# Step 7: Ask for food expenses
food = float(input("How much will you spend on food? "))

# Step 8: Add expenses
expenses = gas + accommodation + food

# Step 9: Subtract expenses from budget
remaining = budget - expenses

# Step 10: Display results
print("\n------------Travel Expenses------------")
print(f"Location: {destination}")
print(f"Initial Budget: ${budget:.2f}")
print(f"Gas: ${gas:.2f}")
print(f"Accommodation: ${accommodation:.2f}")
print(f"Food: ${food:.2f}")
print("---------------------------------------")
print(f"Total Expenses: ${expenses:.2f}")
print(f"Remaining Balance: ${remaining:.2f}")
